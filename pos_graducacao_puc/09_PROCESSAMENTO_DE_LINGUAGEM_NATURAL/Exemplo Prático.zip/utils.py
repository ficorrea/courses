import re
from nltk.corpus import stopwords
import string
import numpy as np

def pre_text_processing(corpus):
    #print("Documento")
    #print("#tokenizacao")
    corpus_alt = re.findall(r"\w+(?:'\w+)?|[^\w\s]", corpus)
    #lowcase 
    corpus_alt = [t.lower() for t in corpus_alt]
    #print("#remove stopwords")
    portugues_stops = stopwords.words('portuguese')
    corpus_alt = [t for t in corpus_alt if t not in portugues_stops]
    #print("#remove pontuação")
    corpus_alt = [t for t in corpus_alt if t not in string.punctuation]
    
    return corpus_alt

def calcula_embedding_frase(tokens):
    return np.mean(np.array([word_vectors[t] for t in tokens if t in word_vectors.vocab]), axis=0)