library(testthat)
library(imager)

test_check("imager")
